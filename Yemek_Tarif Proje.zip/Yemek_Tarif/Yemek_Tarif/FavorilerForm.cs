﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Yemek_Tarif
{
    public partial class FavorilerForm : Form
    {
        public FavorilerForm()
        {
            InitializeComponent();
        }

        List<TarifMalzemeler> tarifMalzemeler = new List<TarifMalzemeler>();

        SqlConnection connection = new SqlConnection("server=.;Initial Catalog=YemekDB;Integrated Security=SSPI");
        List<Tarifler> favoriTarifler = new List<Tarifler>();
        private void FavorilerForm_Load(object sender, EventArgs e)
        {
            favoriTarifler.Clear();
            SqlConnection baglanti = new SqlConnection("server=.;Initial Catalog=YemekDB;Integrated Security=SSPI");
            baglanti.Open();
            SqlCommand command = new SqlCommand("SELECT * FROM Tarifler INNER JOIN Favoriler ON Tarifler.TarifID = Favoriler.TarifID", baglanti);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Tarifler item = new Tarifler
                {
                    TarifID = Convert.ToInt32(reader["TarifID"]),
                    Isim = reader["Isim"].ToString(),
                    Aciklama = reader["Aciklama"].ToString(),
                    HazirlamaSuresi = Convert.ToInt32(reader["HazirlamaSuresi"])
                };
                favoriTarifler.Add(item);
            }
            baglanti.Close();


            Goster(favoriTarifler);
        }

        void DataShow2()
        {
            tarifMalzemeler.Clear();
            SqlConnection baglanti = new SqlConnection("server=.;Initial Catalog=YemekDB;Integrated Security=SSPI");
            baglanti.Open();
            SqlCommand command = new SqlCommand("SELECT *FROM TarifMalzemeler", baglanti);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                TarifMalzemeler malzemeler = new TarifMalzemeler();
                malzemeler.MalzemeID = Convert.ToInt32(reader["MalzemeID"]);
                malzemeler.TarifID = Convert.ToInt32(reader["TarifID"]);
                malzemeler.Miktar = reader["Miktar"].ToString();
                malzemeler.Isim = reader["Isim"].ToString();
                tarifMalzemeler.Add(malzemeler);
            }
            baglanti.Close();
            //tariflerDataGridView.DataSource = tarifMalzemeler;
        }

        List<Button> listButtons = new List<Button>();
        List<Button> favButtons = new List<Button>();

        void Goster(List<Tarifler> t)
        {

            listButtons.Clear();
            favButtons.Clear();

            DataShow2();

            anaPanel.Controls.Clear();

            int x = 10;

            for (int i = 0; i < t.Count; i++)
            {

                Panel p = new Panel()
                {
                    Top = x,
                    Left = 10,
                    Height = 200,
                    Width = anaPanel.Width - 20,
                    BackColor = Color.White
                };
                x += 210;

                p.Controls.Add(new Label()
                {
                    Top = 15,
                    Left = 15,
                    Text = t[i].Isim,
                    Width = 200,
                    Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold)
                }); ;

                String txt = "";
                for (int j = 0; j <= t[i].Aciklama.Length / 50; j++)
                {
                    if (j != t[i].Aciklama.Length / 50)
                    {
                        txt += t[i].Aciklama.Substring(j * 50, 50) + "\n";
                    }
                    else
                    {
                        txt += t[i].Aciklama.Substring(j * 50, t[i].Aciklama.Length % 50);
                    }
                }

                p.Controls.Add(new Label()
                {
                    Top = 40,
                    Left = 15,
                    Width = 400,
                    Text = txt
                });

                p.Controls.Add(new Label()
                {
                    Top = 170,
                    Left = 15,
                    Text = "Tahmini Hazzırlama Süresi: " + t[i].HazirlamaSuresi + " dk",

                    Width = 400,
                    Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold)
                }); ;

                p.Controls.Add(new Label()
                {
                    Top = 40,
                    Left = 500,
                    Text = "Malzemeler: ",
                    Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold)
                }); ;


                List<TarifMalzemeler> m = new List<TarifMalzemeler>();

                for (int j = 0; j < tarifMalzemeler.Count; j++)
                {
                    if (tarifMalzemeler[j].TarifID == t[i].TarifID)
                    {
                        m.Add(tarifMalzemeler[j]);
                    }
                }

                int tp = 10, lf = 450;


                for (int k = 0; k < m.Count; k++)
                {
                    tp += 30;
                    if (k % 5 == 0)
                    {
                        tp = 40;
                        lf += 150;
                    }
                    p.Controls.Add(new Label()
                    {
                        Top = tp,
                        Left = lf,
                        Text = m[k].Isim,
                        Font = new Font("Microsoft Sans Serif", 8, FontStyle.Regular)
                    }); ;

                }

                Button l = new Button()
                {
                    Top = 60,
                    Left = 500,
                    Text = "Listeme Ekle",
                };
                l.Click += new EventHandler(ListemeEkle_Click);
                listButtons.Add(l);
                p.Controls.Add(l);

                Button f = new Button()
                {
                    Top = 10,
                    Left = p.Width - 85,
                    Text = "Favorilere Ekle",
                };
                f.Click += new EventHandler(FavorilereEkle_Click);
                favButtons.Add(f);
                p.Controls.Add(f);


                anaPanel.Controls.Add(p);
            }




        }


        void ListemeEkle_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            int index = listButtons.IndexOf(b);

            /*
             * tarifler[index] içindeki tüm malzemeler alışveriş listesine eklenecek
             */
            int seciliTarifID = favoriTarifler[index].TarifID;

            List<int> iDler = new List<int>();

            connection.Open();
            SqlCommand command = new SqlCommand("SELECT * FROM TarifMalzemeler WHERE TarifID = " + seciliTarifID, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                iDler.Add(Convert.ToInt32(reader["MalzemeID"]));
            }
            connection.Close();

            string sorgu = "INSERT INTO AlisverisListesi(MalzemeID) VALUES (@MalzemeID)";


            foreach (var item in iDler)
            {
                connection.Open();
                command = new SqlCommand(sorgu, connection);
                command.Parameters.AddWithValue("@MalzemeID", item);
                command.ExecuteNonQuery();
                connection.Close();
            }
        }

        void FavorilereEkle_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            int index = favButtons.IndexOf(b);

            /*
             * tarifler[index] favorilere eklenecek
             */
            int seciliTarifID = favoriTarifler[index].TarifID;

            string sorgu = "DELETE FROM Favoriler WHERE TarifID = " + seciliTarifID;
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("@TarifID", seciliTarifID);
            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();;
        }


    }
}
