﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Yemek_Tarif
{
    public partial class Giris : Form
    {
        public Giris()
        {
            InitializeComponent();
        }

        private void anaFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AnaForm anaForm = new AnaForm();
            anaForm.Show();
        }

        private void alışverişListesiFormuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AlisverisListesiForm alisverisListesiForm = new AlisverisListesiForm();
            alisverisListesiForm.Show();
        }

        private void favorilerFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FavorilerForm favorilerForm = new FavorilerForm();
            favorilerForm.Show();
        }

        private void tarifEkleFormuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TarifEkleForm tarifEkleForm = new TarifEkleForm();
            tarifEkleForm.Show();
        }
    }
}
