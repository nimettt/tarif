﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Yemek_Tarif
{
    public partial class AnaForm : Form
    {
        public AnaForm()
        {
            InitializeComponent();            
        }
        SqlConnection baglanti = new SqlConnection("server=.;Initial Catalog=YemekDB;Integrated Security=SSPI");
        SqlCommand command;
        SqlDataAdapter da;
        DialogResult dialog = new DialogResult();
        List<Tarifler> tarifler = new List<Tarifler>();
        List<TarifMalzemeler> tarifMalzemeler = new List<TarifMalzemeler>();
        public int seciliTarifID;


        List<Button> listButtons = new List<Button>();
        List<Button> favButtons = new List<Button>();
        List<Button> kaldirButtons = new List<Button>();

        void Goster()
        {

            listButtons.Clear();
            favButtons.Clear();
            kaldirButtons.Clear();
            DataShow();
            DataShow2();

            anaPanel.Controls.Clear();

            int x = 10;

            for (int i = 0; i < tarifler.Count; i++)
            {

                Panel p = new Panel()
                {
                    Top = x,
                    Left = 10,
                    Height = 200,
                    Width = anaPanel.Width - 20,
                    BackColor = Color.White
                };
                x += 210;

                p.Controls.Add(new Label()
                {
                    Top = 15,
                    Left = 15,
                    Text = tarifler[i].Isim,
                    Width = 200,
                    Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold)
                }); ;

                String txt = "";
                for (int j = 0; j <= tarifler[i].Aciklama.Length / 50; j++)
                {
                    if (j != tarifler[i].Aciklama.Length / 50)
                    {
                        txt += tarifler[i].Aciklama.Substring(j * 50, 50) + "\n";
                    }
                    else
                    {
                        txt += tarifler[i].Aciklama.Substring(j * 50, tarifler[i].Aciklama.Length % 50);
                    }
                }

                p.Controls.Add(new Label()
                {
                    Top = 40,
                    Left = 15,
                    Width = 400,
                    Text = txt
                });

                p.Controls.Add(new Label()
                {
                    Top = 170,
                    Left = 15,
                    Text = "Tahmini Hazzırlama Süresi: " + tarifler[i].HazirlamaSuresi + " dk",

                    Width = 400,
                    Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold)
                }); ;

                p.Controls.Add(new Label()
                {
                    Top = 40,
                    Left = 500,
                    Text = "Malzemeler: ",
                    Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold)
                }); ;


                List<TarifMalzemeler> m = new List<TarifMalzemeler>();

                for (int j = 0; j < tarifMalzemeler.Count; j++)
                {
                    if (tarifMalzemeler[j].TarifID == tarifler[i].TarifID)
                    {
                        m.Add(tarifMalzemeler[j]);
                    }
                }

                int tp = 10, lf = 450;


                for (int k = 0; k < m.Count; k++)
                {
                    tp += 30;
                    if (k % 5 == 0)
                    {
                        tp = 40;
                        lf += 150;
                    }
                    p.Controls.Add(new Label()
                    {
                        Top = tp,
                        Left = lf,
                        Text = m[k].Isim,
                        Font = new Font("Microsoft Sans Serif", 8, FontStyle.Regular)
                    }); ;

                }

                Button l = new Button()
                {
                    Top = 60,
                    Left = 500,
                    Text = "Listeme Ekle",
                };
                l.Click += new EventHandler(ListemeEkle_Click);
                
                p.Controls.Add(l);
                listButtons.Add(l);

                Button f = new Button()
                {
                    Top = 10,
                    Left = p.Width - 85,
                    Text = "Favorilere Ekle",
                };
                f.Click += new EventHandler(FavorilereEkle_Click);
                
                p.Controls.Add(f);
                favButtons.Add(f);

                Button s = new Button()
                {
                    Top = 35,
                    Left = p.Width - 85,
                    Text = "Kaldır",
                };
                s.Click += new EventHandler(Kaldır_Click);

                p.Controls.Add(s);
                kaldirButtons.Add(s);

                anaPanel.Controls.Add(p);
            }




        }

        void Kaldır_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            int index = kaldirButtons.IndexOf(b);
            int seciliTarifID = tarifler[index].TarifID;

            string sorgu = "DELETE FROM Tarifler WHERE TarifID = " + seciliTarifID;
            SqlCommand command = new SqlCommand(sorgu, baglanti);
            baglanti.Open();
            command.ExecuteNonQuery();
            baglanti.Close();
            kaldirButtons.Remove(b);
        }

        void ListemeEkle_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            int index = listButtons.IndexOf(b);
            int seciliTarifID = tarifler[index].TarifID;

            List<int> iDler = new List<int>();

            baglanti.Open();
            SqlCommand command = new SqlCommand("SELECT * FROM TarifMalzemeler WHERE TarifID = " + seciliTarifID, baglanti);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                iDler.Add(Convert.ToInt32(reader["MalzemeID"]));
            }
            baglanti.Close();

            string sorgu = "INSERT INTO AlisverisListesi(MalzemeID) VALUES (@MalzemeID)";
            

            foreach (var item in iDler)
            {
                baglanti.Open();
                command = new SqlCommand(sorgu, baglanti);
                command.Parameters.AddWithValue("@MalzemeID", item);
                command.ExecuteNonQuery();
                baglanti.Close();
            }

            


            toolStripStatusLabel1.Text = "Sepete Eklendi !";
            statusStrip1.Refresh();
        }

        void FavorilereEkle_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            int index = favButtons.IndexOf(b);
            int seciliTarifID = tarifler[index].TarifID;

            string sorgu = "INSERT INTO Favoriler(TarifID) VALUES (@TarifID)";
            command = new SqlCommand(sorgu, baglanti);
            command.Parameters.AddWithValue("@TarifID", seciliTarifID);
            baglanti.Open();
            command.ExecuteNonQuery();
            baglanti.Close();
            toolStripStatusLabel1.Text = "Favorilere Eklendi !";
            statusStrip1.Refresh();
        }


        void DataShow()
        {
            tarifler.Clear();
            SqlConnection baglanti = new SqlConnection("server=.;Initial Catalog=YemekDB;Integrated Security=SSPI");
            baglanti.Open();
            SqlCommand command = new SqlCommand("SELECT *FROM Tarifler", baglanti);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Tarifler tarif = new Tarifler();
                tarif.TarifID = Convert.ToInt32(reader["TarifID"]);
                tarif.Isim = reader["Isim"].ToString();
                tarif.Aciklama = reader["Aciklama"].ToString();
                tarif.HazirlamaSuresi = Convert.ToInt32(reader["HazirlamaSuresi"]);
                tarifler.Add(tarif);
            }
            baglanti.Close();
        }
        void DataShow2()
        {
            tarifMalzemeler.Clear();
            SqlConnection baglanti = new SqlConnection("server=.;Initial Catalog=YemekDB;Integrated Security=SSPI");
            baglanti.Open();
            SqlCommand command = new SqlCommand("SELECT *FROM TarifMalzemeler", baglanti);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                TarifMalzemeler malzemeler = new TarifMalzemeler();
                malzemeler.MalzemeID = Convert.ToInt32(reader["MalzemeID"]);
                malzemeler.TarifID = Convert.ToInt32(reader["TarifID"]);
                malzemeler.Miktar = reader["Miktar"].ToString();
                malzemeler.Isim = reader["Isim"].ToString();
                tarifMalzemeler.Add(malzemeler);
            }
            baglanti.Close();
        }
        private void AnaForm_Load(object sender, EventArgs e)
        {
            
            toolStripStatusLabel1.Text = "Tarifler  Listeleniyor !";
            statusStrip1.Refresh();
            Application.DoEvents();
            Goster();
        }

        private void favorilerBtn_Click(object sender, EventArgs e)
        {
            FavorilerForm favorilerForm = new FavorilerForm();
            favorilerForm.Show();
        }

        private void listeBtn_Click(object sender, EventArgs e)
        {
            AlisverisListesiForm alisverisListesiForm = new AlisverisListesiForm();
            alisverisListesiForm.Show();
        }

        private void tarifekleBtn_Click(object sender, EventArgs e)
        {
            TarifEkleForm tarifEkleForm = new TarifEkleForm();  
            tarifEkleForm.Show();
        }

        private void yenileBtn_Click(object sender, EventArgs e)
        {
            Goster();
        }
    }
}
