﻿
namespace Yemek_Tarif
{
    partial class FavorilerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.anaPanel = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // anaPanel
            // 
            this.anaPanel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.anaPanel.Location = new System.Drawing.Point(13, 13);
            this.anaPanel.Name = "anaPanel";
            this.anaPanel.Size = new System.Drawing.Size(1131, 676);
            this.anaPanel.TabIndex = 0;
            // 
            // FavorilerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 701);
            this.Controls.Add(this.anaPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "FavorilerForm";
            this.Text = "FavorilerForm";
            this.Load += new System.EventHandler(this.FavorilerForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel anaPanel;
    }
}