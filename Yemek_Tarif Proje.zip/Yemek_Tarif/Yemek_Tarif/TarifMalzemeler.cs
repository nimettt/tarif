﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yemek_Tarif
{
    public class TarifMalzemeler
    {
        public int MalzemeID { get; set; }
        public int TarifID { get; set; }
        public string Miktar { get; set; }
        public string Isim { get; set; }
    }
}
