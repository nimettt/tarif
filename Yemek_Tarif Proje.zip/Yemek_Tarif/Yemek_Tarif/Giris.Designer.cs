﻿
namespace Yemek_Tarif
{
    partial class Giris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.anaFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.favorilerFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alışverişListesiFormuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tarifEkleFormuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.anaFormToolStripMenuItem,
            this.alışverişListesiFormuToolStripMenuItem,
            this.favorilerFormToolStripMenuItem,
            this.tarifEkleFormuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1294, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // anaFormToolStripMenuItem
            // 
            this.anaFormToolStripMenuItem.Name = "anaFormToolStripMenuItem";
            this.anaFormToolStripMenuItem.Size = new System.Drawing.Size(101, 29);
            this.anaFormToolStripMenuItem.Text = "AnaForm";
            this.anaFormToolStripMenuItem.Click += new System.EventHandler(this.anaFormToolStripMenuItem_Click);
            // 
            // favorilerFormToolStripMenuItem
            // 
            this.favorilerFormToolStripMenuItem.Name = "favorilerFormToolStripMenuItem";
            this.favorilerFormToolStripMenuItem.Size = new System.Drawing.Size(151, 29);
            this.favorilerFormToolStripMenuItem.Text = "Favoriler Formu";
            this.favorilerFormToolStripMenuItem.Click += new System.EventHandler(this.favorilerFormToolStripMenuItem_Click);
            // 
            // alışverişListesiFormuToolStripMenuItem
            // 
            this.alışverişListesiFormuToolStripMenuItem.Name = "alışverişListesiFormuToolStripMenuItem";
            this.alışverişListesiFormuToolStripMenuItem.Size = new System.Drawing.Size(201, 29);
            this.alışverişListesiFormuToolStripMenuItem.Text = "Alışveriş Listesi Formu";
            this.alışverişListesiFormuToolStripMenuItem.Click += new System.EventHandler(this.alışverişListesiFormuToolStripMenuItem_Click);
            // 
            // tarifEkleFormuToolStripMenuItem
            // 
            this.tarifEkleFormuToolStripMenuItem.Name = "tarifEkleFormuToolStripMenuItem";
            this.tarifEkleFormuToolStripMenuItem.Size = new System.Drawing.Size(153, 29);
            this.tarifEkleFormuToolStripMenuItem.Text = "Tarif Ekle Formu";
            this.tarifEkleFormuToolStripMenuItem.Click += new System.EventHandler(this.tarifEkleFormuToolStripMenuItem_Click);
            // 
            // Giris
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1294, 543);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Giris";
            this.Text = "Giris";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem anaFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem favorilerFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alışverişListesiFormuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tarifEkleFormuToolStripMenuItem;
    }
}