﻿
namespace Yemek_Tarif
{
    partial class AnaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.anaPanel = new System.Windows.Forms.Panel();
            this.favorilerBtn = new System.Windows.Forms.Button();
            this.listeBtn = new System.Windows.Forms.Button();
            this.tarifekleBtn = new System.Windows.Forms.Button();
            this.yenileBtn = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 679);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 9, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1164, 22);
            this.statusStrip1.TabIndex = 7;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // anaPanel
            // 
            this.anaPanel.AutoScroll = true;
            this.anaPanel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.anaPanel.Location = new System.Drawing.Point(12, 80);
            this.anaPanel.Name = "anaPanel";
            this.anaPanel.Size = new System.Drawing.Size(1138, 595);
            this.anaPanel.TabIndex = 13;
            // 
            // favorilerBtn
            // 
            this.favorilerBtn.Location = new System.Drawing.Point(1065, 41);
            this.favorilerBtn.Name = "favorilerBtn";
            this.favorilerBtn.Size = new System.Drawing.Size(85, 23);
            this.favorilerBtn.TabIndex = 14;
            this.favorilerBtn.Text = "Favoriler";
            this.favorilerBtn.UseVisualStyleBackColor = true;
            this.favorilerBtn.Click += new System.EventHandler(this.favorilerBtn_Click);
            // 
            // listeBtn
            // 
            this.listeBtn.Location = new System.Drawing.Point(1065, 12);
            this.listeBtn.Name = "listeBtn";
            this.listeBtn.Size = new System.Drawing.Size(85, 23);
            this.listeBtn.TabIndex = 15;
            this.listeBtn.Text = "Alışveriş Listesi";
            this.listeBtn.UseVisualStyleBackColor = true;
            this.listeBtn.Click += new System.EventHandler(this.listeBtn_Click);
            // 
            // tarifekleBtn
            // 
            this.tarifekleBtn.Location = new System.Drawing.Point(12, 41);
            this.tarifekleBtn.Name = "tarifekleBtn";
            this.tarifekleBtn.Size = new System.Drawing.Size(100, 23);
            this.tarifekleBtn.TabIndex = 16;
            this.tarifekleBtn.Text = "Yeni Tarif Ekle";
            this.tarifekleBtn.UseVisualStyleBackColor = true;
            this.tarifekleBtn.Click += new System.EventHandler(this.tarifekleBtn_Click);
            // 
            // yenileBtn
            // 
            this.yenileBtn.Location = new System.Drawing.Point(12, 12);
            this.yenileBtn.Name = "yenileBtn";
            this.yenileBtn.Size = new System.Drawing.Size(75, 23);
            this.yenileBtn.TabIndex = 17;
            this.yenileBtn.Text = "Yenile";
            this.yenileBtn.UseVisualStyleBackColor = true;
            this.yenileBtn.Click += new System.EventHandler(this.yenileBtn_Click);
            // 
            // AnaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 701);
            this.Controls.Add(this.yenileBtn);
            this.Controls.Add(this.tarifekleBtn);
            this.Controls.Add(this.listeBtn);
            this.Controls.Add(this.favorilerBtn);
            this.Controls.Add(this.anaPanel);
            this.Controls.Add(this.statusStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "AnaForm";
            this.Text = "AnaForm";
            this.Load += new System.EventHandler(this.AnaForm_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Panel anaPanel;
        private System.Windows.Forms.Button favorilerBtn;
        private System.Windows.Forms.Button listeBtn;
        private System.Windows.Forms.Button tarifekleBtn;
        private System.Windows.Forms.Button yenileBtn;
    }
}

