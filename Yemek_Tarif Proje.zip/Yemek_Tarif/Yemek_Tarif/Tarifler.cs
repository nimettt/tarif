﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yemek_Tarif
{
    public class Tarifler
    {
        public int TarifID { get; set; }
        public string Isim { get; set; }
        public string Aciklama { get; set; }
        public int HazirlamaSuresi { get; set; }
        public string MalzemeIer { get; set; }
    }
}
