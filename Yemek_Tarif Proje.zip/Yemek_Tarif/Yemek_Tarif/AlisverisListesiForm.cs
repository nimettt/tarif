﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Yemek_Tarif
{
    public partial class AlisverisListesiForm : Form
    {
        public AlisverisListesiForm()
        {
            InitializeComponent();
        }
        SqlConnection connection = new SqlConnection("server=.;Initial Catalog=YemekDB;Integrated Security=SSPI");
        List<TarifMalzemeler> alisverisListesi = new List<TarifMalzemeler>();
        private void AlisverisListesiForm_Load(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand command = new SqlCommand("SELECT * FROM TarifMalzemeler INNER JOIN AlisverisListesi ON TarifMalzemeler.MalzemeID = AlisverisListesi.MalzemeID", connection);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                TarifMalzemeler item = new TarifMalzemeler
                {
                    MalzemeID = Convert.ToInt32(reader["MalzemeID"]),
                    Isim = reader["Isim"].ToString(),
                    Miktar = reader["Miktar"].ToString()
                };
                alisverisListesi.Add(item);
            }
            connection.Close();
            Listele();
        }
        List<CheckBox> chbxList=  new List<CheckBox>();

        void Listele()
        {
            chbxList.Clear();
            panel.Controls.Clear();

            for (int i = 0; i < alisverisListesi.Count; i++)
            {
                panel.Controls.Add(new Label()
                {
                    Text = alisverisListesi[i].Isim.ToString(),
                    Left = 5,
                    Top = i * 25,
                });
                panel.Controls.Add(new Label()
                {
                    Text = alisverisListesi[i].Miktar.ToString(),
                    Left = 150,
                    Top = i * 25,
                });
                CheckBox c = new CheckBox()
                {
                    Text = "",
                    Left = 330,
                    Top = i * 25,
                };
                chbxList.Add(c);
                panel.Controls.Add(c);
            }
        }



        private void AlisverisListesiForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            for (int i = 0; i < chbxList.Count; i++)
            {
                if (chbxList[i].Checked)
                {
                    string sorgu = "DELETE FROM AlisverisListesi WHERE MalzemeID = " + alisverisListesi[i].MalzemeID;
                    SqlCommand command = new SqlCommand(sorgu, connection);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
        }

    }
}
