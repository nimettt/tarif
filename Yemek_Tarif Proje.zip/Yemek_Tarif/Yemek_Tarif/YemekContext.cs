﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yemek_Tarif
{
    public class YemekContext : DbContext 
    {
        public YemekContext()
        {
            Database.Connection.ConnectionString = "server=.;Initial Catalog=YemekDB;Integrated Security=SSPI";
        }
        public DbSet<Tarifler> Tarifler { get; set; }
        public DbSet<TarifMalzemeler> TarifMalzemeler { get; set; }
    }
}
