﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Yemek_Tarif
{
    public partial class TarifEkleForm : Form
    {
        public TarifEkleForm()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("server=.;Initial Catalog=YemekDB;Integrated Security=SSPI");
        SqlCommand command;
        SqlDataAdapter da;
        DialogResult dialog = new DialogResult();

        List<Tuple<string, string>> malzemeler = new List<Tuple<string, string>>();
        SqlConnection connection = new SqlConnection("server=.;Initial Catalog=YemekDB;Integrated Security=SSPI");
        private void btnEkle_Click(object sender, EventArgs e)
        {
            string malzemelerStr = string.Join(", ", listBox1.Items.Cast<string>());

            string sorgu1 = "INSERT INTO Tarifler(Isim, Aciklama, HazirlamaSuresi) OUTPUT INSERTED.TarifID VALUES (@Isim, @Aciklama, @HazirlamaSuresi)";
            string sorgu2 = "INSERT INTO TarifMalzemeler(MalzemeID, TarifID, Isim, Miktar) VALUES (@MalzemeID, @TarifID, @Isim, @Miktar)";

            command = new SqlCommand(sorgu1, baglanti);
            command.Parameters.AddWithValue("@Isim", txtisim.Text);
            command.Parameters.AddWithValue("@Aciklama", rtbAciklama.Text);
            command.Parameters.AddWithValue("@HazirlamaSuresi", txtsure.Text);
            //command.Parameters.AddWithValue("@Malzemeler", malzemelerStr);

            baglanti.Open();
            SqlTransaction sqlTran = baglanti.BeginTransaction();
            command.Transaction = sqlTran;

            try
            {
                int tarifID = (int)command.ExecuteScalar();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM TarifMalzemeler", connection);
                DataTable dt = new DataTable();
                da.Fill(dt);
                int malzemeSayi = dt.Select().Length;
                int a = 0;
                foreach (var malzeme in malzemeler)
                {
                    command = new SqlCommand(sorgu2, baglanti);
                    command.Transaction = sqlTran;
                    command.Parameters.AddWithValue("@MalzemeID", malzemeSayi + a);
                    command.Parameters.AddWithValue("@TarifID", tarifID);
                    command.Parameters.AddWithValue("@Isim", malzeme.Item1);
                    command.Parameters.AddWithValue("@Miktar", malzeme.Item2);
                    command.ExecuteNonQuery();
                    a++;
                }

                sqlTran.Commit();
                toolStripStatusLabel1.Text = "Tarif Başarılı Bir Şekilde Eklendi !";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
                sqlTran.Rollback();
            }
            finally
            {
                baglanti.Close();
            }
        }

        private void rtbAciklama_TextChanged(object sender, EventArgs e)
        {
            if (rtbAciklama.Text.Length > 400)
            {
                rtbAciklama.Text = rtbAciklama.Text.Substring(0, 400);
                MessageBox.Show("Açıklama 400 karakterden fazla olamaz.");
            }
        }

        private void btnMalzemeEkle_Click_1(object sender, EventArgs e)
        {
            malzemeler.Add(new Tuple<string, string>(txtMalzeme.Text, txtMiktar.Text));
            listBox1.Items.Add($"{txtMalzeme.Text} - {txtMiktar.Text}");
            txtMalzeme.Text = "";
            txtMiktar.Text = "";
        }
    }
}
